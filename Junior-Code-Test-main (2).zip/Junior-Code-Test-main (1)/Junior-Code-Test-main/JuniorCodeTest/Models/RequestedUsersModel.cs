﻿namespace JuniorCodeTest.Models
{
	public class RequestedUsersModel
	{
		public string? Title { get; set; }
		public string? First { get; set; }
		public string? Last { get; set; }
		public int Age { get; set; }
		public string? Latitude { get; set; }
		public string? Longitude { get; set; }
		public string? Country { get; set; }
	}
}
